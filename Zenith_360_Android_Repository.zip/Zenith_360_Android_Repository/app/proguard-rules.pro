# ============================================================================
# ZENITH 360 - R8 / PROGUARD FULL-MODE OBFUSCATION & SHRINKING RULES
# Package: com.zenith.architect.pro
# ============================================================================

-optimizationpasses 5
-allowaccessmodification
-repackageclasses 'com.zenith.architect.pro.obf'
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Strip debug/verbose logging in production release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# Keep Room Database Entities & DAOs
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }

# Keep Hilt Generated Classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Keep Google Mobile Ads (AdMob) & UMP Consent SDK
-keep public class com.google.android.gms.ads.** { public *; }
-keep public class com.google.ads.** { public *; }
-keep public class com.google.android.ump.** { public *; }
-dontwarn com.google.android.gms.**

# Keep Kotlin Coroutines & Serialization metadata
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Keep Security Crypto (EncryptedSharedPreferences / Tink)
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Preserve line numbers for Play Console crash symbolication while obfuscating
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
