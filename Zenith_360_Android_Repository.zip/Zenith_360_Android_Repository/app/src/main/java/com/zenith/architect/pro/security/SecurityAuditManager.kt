package com.zenith.architect.pro.security

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Debug
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class DeviceSecurityReport(
    val isRooted: Boolean,
    val isEmulator: Boolean,
    val isDebuggable: Boolean,
    val isDebuggerAttached: Boolean,
    val isPackageValid: Boolean,
    val encryptedVaultActive: Boolean
) {
    val integrityScore: Int
        get() {
            var score = 100
            if (isRooted) score -= 35
            if (isEmulator) score -= 15
            if (isDebuggable) score -= 15
            if (isDebuggerAttached) score -= 25
            if (!isPackageValid) score -= 40
            return score.coerceIn(0, 100)
        }
}

@Singleton
class SecurityAuditManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val expectedPackageBase = "com.zenith.architect.pro"

    private val encryptedPrefs: SharedPreferences? by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "zenith_encrypted_vault",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            null
        }
    }

    fun performSecurityAudit(): DeviceSecurityReport {
        val vaultReady = verifyEncryptedVault()
        return DeviceSecurityReport(
            isRooted = checkRootIndicators(),
            isEmulator = checkEmulatorIndicators(),
            isDebuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0,
            isDebuggerAttached = Debug.isDebuggerConnected() || Debug.waitingForDebugger(),
            isPackageValid = context.packageName.startsWith(expectedPackageBase),
            encryptedVaultActive = vaultReady
        )
    }

    private fun verifyEncryptedVault(): Boolean {
        return try {
            val prefs = encryptedPrefs ?: return false
            if (!prefs.contains("vault_initialized_ts")) {
                prefs.edit().putLong("vault_initialized_ts", System.currentTimeMillis()).apply()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun saveEncryptedToken(key: String, value: String) {
        encryptedPrefs?.edit()?.putString(key, value)?.apply()
    }

    fun readEncryptedToken(key: String): String? {
        return encryptedPrefs?.getString(key, null)
    }

    private fun checkRootIndicators(): Boolean {
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }
        val suPaths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        return suPaths.any { path ->
            try {
                File(path).exists()
            } catch (_: SecurityException) {
                false
            }
        }
    }

    private fun checkEmulatorIndicators(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.lowercase().contains("vbox")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk" == Build.PRODUCT)
    }
}
