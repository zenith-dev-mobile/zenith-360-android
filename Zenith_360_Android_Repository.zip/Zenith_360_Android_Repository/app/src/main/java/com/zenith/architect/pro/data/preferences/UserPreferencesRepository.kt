package com.zenith.architect.pro.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.zenithDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "zenith_360_user_preferences"
)

data class ZenithUserPreferences(
    val isDarkMode: Boolean = true,
    val currencySymbol: String = "$",
    val monthlySavingsGoal: Double = 2500.0,
    val isPrivacyShieldEnabled: Boolean = false,
    val isVipForecastUnlocked: Boolean = false,
    val lastSelectedTabIndex: Int = 0,
    val preferredLanguageCode: String = "en",
    val completedTasksCounter: Int = 0
)

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
        val MONTHLY_SAVINGS_GOAL = doublePreferencesKey("monthly_savings_goal")
        val PRIVACY_SHIELD = booleanPreferencesKey("privacy_shield")
        val VIP_FORECAST_UNLOCKED = booleanPreferencesKey("vip_forecast_unlocked")
        val LAST_SELECTED_TAB = intPreferencesKey("last_selected_tab")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val COMPLETED_TASKS_COUNTER = intPreferencesKey("completed_tasks_counter")
    }

    val userPreferencesFlow: Flow<ZenithUserPreferences> = context.zenithDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            ZenithUserPreferences(
                isDarkMode = prefs[Keys.DARK_MODE] ?: true,
                currencySymbol = prefs[Keys.CURRENCY_SYMBOL] ?: "$",
                monthlySavingsGoal = prefs[Keys.MONTHLY_SAVINGS_GOAL] ?: 2500.0,
                isPrivacyShieldEnabled = prefs[Keys.PRIVACY_SHIELD] ?: false,
                isVipForecastUnlocked = prefs[Keys.VIP_FORECAST_UNLOCKED] ?: false,
                lastSelectedTabIndex = prefs[Keys.LAST_SELECTED_TAB] ?: 0,
                preferredLanguageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
                completedTasksCounter = prefs[Keys.COMPLETED_TASKS_COUNTER] ?: 0
            )
        }

    suspend fun setDarkMode(enabled: Boolean) {
        context.zenithDataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setCurrencySymbol(symbol: String) {
        context.zenithDataStore.edit { it[Keys.CURRENCY_SYMBOL] = symbol }
    }

    suspend fun setMonthlySavingsGoal(goal: Double) {
        context.zenithDataStore.edit { it[Keys.MONTHLY_SAVINGS_GOAL] = goal }
    }

    suspend fun setPrivacyShield(enabled: Boolean) {
        context.zenithDataStore.edit { it[Keys.PRIVACY_SHIELD] = enabled }
    }

    suspend fun setVipForecastUnlocked(unlocked: Boolean) {
        context.zenithDataStore.edit { it[Keys.VIP_FORECAST_UNLOCKED] = unlocked }
    }

    suspend fun setLastSelectedTab(index: Int) {
        context.zenithDataStore.edit { it[Keys.LAST_SELECTED_TAB] = index }
    }

    suspend fun setPreferredLanguage(code: String) {
        context.zenithDataStore.edit { it[Keys.LANGUAGE_CODE] = code }
    }

    suspend fun incrementCompletedTasks(): Int {
        var updated = 0
        context.zenithDataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_TASKS_COUNTER] ?: 0
            updated = current + 1
            prefs[Keys.COMPLETED_TASKS_COUNTER] = updated
        }
        return updated
    }
}
