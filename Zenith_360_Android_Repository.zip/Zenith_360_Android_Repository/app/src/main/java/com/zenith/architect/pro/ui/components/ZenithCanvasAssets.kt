package com.zenith.architect.pro.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenith.architect.pro.ui.theme.ZenithDeepNavy
import com.zenith.architect.pro.ui.theme.ZenithGold
import com.zenith.architect.pro.ui.theme.ZenithGoldDeep
import com.zenith.architect.pro.ui.theme.ZenithMidnightSurface
import com.zenith.architect.pro.ui.theme.ZenithNeonCyan
import com.zenith.architect.pro.ui.theme.ZenithNeonEmerald
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * 100% Pure Kotlin Jetpack Compose Canvas-Rendered Logo & Icon.
 * Renders a multi-layered sacred geometric dodecagon compass, orbital neon rings,
 * and a crystalline golden Zenith apex pyramid with zero external bitmap/SVG dependencies.
 */
@Composable
fun ZenithCanvasLogo(
    modifier: Modifier = Modifier.size(96.dp),
    animatedRotationDegrees: Float = 0f
) {
    Canvas(
        modifier = modifier.semantics {
            contentDescription = "Zenith 360 Geometric Compass and Gold Pyramid Emblem"
        }
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f

        // Outer ambient radial glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ZenithGold.copy(alpha = 0.35f),
                    ZenithNeonCyan.copy(alpha = 0.14f),
                    Color.Transparent
                ),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )

        // Deep Navy core medallion
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF0E172E), ZenithDeepNavy)
            ),
            radius = radius * 0.84f,
            center = center
        )

        // Rotating orbital cyber-ring
        rotate(degrees = animatedRotationDegrees, pivot = center) {
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        ZenithGold,
                        ZenithNeonCyan,
                        ZenithNeonEmerald,
                        ZenithGold
                    ),
                    center = center
                ),
                radius = radius * 0.80f,
                center = center,
                style = Stroke(width = radius * 0.055f)
            )

            // 12 Geometric compass ticks around the ring
            for (i in 0 until 12) {
                val angleRad = Math.toRadians((i * 30.0))
                val innerR = if (i % 3 == 0) radius * 0.66f else radius * 0.72f
                val outerR = radius * 0.78f
                val start = Offset(
                    x = center.x + (innerR * cos(angleRad)).toFloat(),
                    y = center.y + (innerR * sin(angleRad)).toFloat()
                )
                val end = Offset(
                    x = center.x + (outerR * cos(angleRad)).toFloat(),
                    y = center.y + (outerR * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = if (i % 3 == 0) ZenithGold else ZenithNeonCyan.copy(alpha = 0.7f),
                    start = start,
                    end = end,
                    strokeWidth = if (i % 3 == 0) radius * 0.04f else radius * 0.02f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Inner Zenith 3D Apex Pyramid (Left illuminated face + Right shadowed face)
        val apex = Offset(center.x, center.y - radius * 0.44f)
        val baseLeft = Offset(center.x - radius * 0.42f, center.y + radius * 0.30f)
        val baseRight = Offset(center.x + radius * 0.42f, center.y + radius * 0.30f)
        val baseCenter = Offset(center.x, center.y + radius * 0.16f)

        val leftFace = Path().apply {
            moveTo(apex.x, apex.y)
            lineTo(baseLeft.x, baseLeft.y)
            lineTo(baseCenter.x, baseCenter.y)
            close()
        }
        drawPath(
            path = leftFace,
            brush = Brush.linearGradient(
                colors = listOf(ZenithGold, ZenithGoldDeep),
                start = apex,
                end = baseLeft
            )
        )

        val rightFace = Path().apply {
            moveTo(apex.x, apex.y)
            lineTo(baseRight.x, baseRight.y)
            lineTo(baseCenter.x, baseCenter.y)
            close()
        }
        drawPath(
            path = rightFace,
            brush = Brush.linearGradient(
                colors = listOf(ZenithGoldDeep, Color(0xFF8A5A00)),
                start = apex,
                end = baseRight
            )
        )

        // Neon Cyan ascending wealth & habit trajectory arrow cutting across the apex
        val trajectoryPath = Path().apply {
            moveTo(center.x - radius * 0.36f, center.y + radius * 0.38f)
            quadraticTo(
                center.x,
                center.y + radius * 0.05f,
                center.x + radius * 0.34f,
                center.y - radius * 0.26f
            )
        }
        drawPath(
            path = trajectoryPath,
            color = ZenithNeonCyan,
            style = Stroke(
                width = radius * 0.055f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

/**
 * Pure Code-Driven 3-Second Cinematic Animated Splash Screen.
 */
@Composable
fun ZenithCinematicSplashScreen(
    onSplashCompleted: () -> Unit
) {
    var startAnim by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        targetValue = if (startAnim) 360f else 0f,
        animationSpec = tween(durationMillis = 2600, easing = FastOutSlowInEasing),
        label = "splash_rotation"
    )
    val scaleAlpha by animateFloatAsState(
        targetValue = if (startAnim) 1f else 0.15f,
        animationSpec = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
        label = "splash_alpha"
    )

    LaunchedEffect(Unit) {
        startAnim = true
        delay(2800L)
        onSplashCompleted()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ZenithDeepNavy,
                        ZenithMidnightSurface,
                        ZenithDeepNavy
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            ZenithCanvasLogo(
                modifier = Modifier.size((136 * scaleAlpha.coerceAtLeast(0.6f)).dp),
                animatedRotationDegrees = rotation
            )
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "ZENITH 360",
                style = MaterialTheme.typography.displayLarge.copy(
                    color = ZenithGold.copy(alpha = scaleAlpha),
                    letterSpacing = 4.sp
                ),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "AI LIFE, HABIT & WEALTH ARCHITECT",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = ZenithNeonCyan.copy(alpha = scaleAlpha),
                    letterSpacing = 2.2.sp,
                    fontSize = 12.sp
                ),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            // Smooth progress bar rendered in pure Canvas
            Canvas(
                modifier = Modifier
                    .width(200.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
            ) {
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.12f),
                    size = size,
                    cornerRadius = CornerRadius(12f, 12f)
                )
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(ZenithGold, ZenithNeonCyan, ZenithNeonEmerald)
                    ),
                    size = Size(size.width * (rotation / 360f).coerceIn(0.05f, 1f), size.height),
                    cornerRadius = CornerRadius(12f, 12f)
                )
            }
        }
    }
}

/**
 * Frosted Glassmorphism Card Container with translucent gradient border and subtle specular highlight.
 */
@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    accentBorderColor: Color = ZenithGold.copy(alpha = 0.32f),
    cornerRadius: Dp = 22.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(cornerRadius))
            .border(
                BorderStroke(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            accentBorderColor,
                            Color.White.copy(alpha = 0.08f),
                             ZenithtransparentAccent(accentBorderColor)
                        )
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            ),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
                .padding(18.dp),
            content = content
        )
    }
}

private fun ZenithtransparentAccent(color: Color): Color = color.copy(alpha = 0.16f)

/**
 * Custom Bezier Area Line Chart rendered in pure Compose Canvas for Wealth & AI Trajectory.
 */
@Composable
fun ZenithBezierTrendChart(
    dataPoints: List<Float>,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(170.dp),
    lineColor: Color = ZenithNeonCyan,
    secondaryColor: Color = ZenithGold
) {
    val safePoints = if (dataPoints.size >= 2) dataPoints else listOf(100f, 220f, 340f, 520f, 760f, 1050f)

    Canvas(
        modifier = modifier.semantics {
            contentDescription = "Zenith 360 Compounding Wealth and Habit Trajectory Graph"
        }
    ) {
        val maxVal = (safePoints.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val minVal = (safePoints.minOrNull() ?: 0f).coerceAtMost(maxVal - 1f)
        val range = (maxVal - minVal).coerceAtLeast(1f)

        val horizontalPadding = 16.dp.toPx()
        val verticalPadding = 18.dp.toPx()
        val usableWidth = (size.width - horizontalPadding * 2).coerceAtLeast(1f)
        val usableHeight = (size.height - verticalPadding * 2).coerceAtLeast(1f)

        // Subtle horizontal reference grid lines
        for (i in 0..3) {
            val y = verticalPadding + (usableHeight / 3f) * i
            drawLine(
                color = Color.White.copy(alpha = 0.08f),
                start = Offset(horizontalPadding, y),
                end = Offset(size.width - horizontalPadding, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        val coordinates = safePoints.mapIndexed { index, value ->
            val x = horizontalPadding + (index.toFloat() / (safePoints.size - 1).toFloat()) * usableWidth
            val normalizedY = (value - minVal) / range
            val y = verticalPadding + usableHeight * (1f - normalizedY)
            Offset(x, y)
        }

        val strokePath = Path().apply {
            moveTo(coordinates.first().x, coordinates.first().y)
            for (i in 0 until coordinates.size - 1) {
                val current = coordinates[i]
                val next = coordinates[i + 1]
                val controlX1 = (current.x + next.x) / 2f
                val controlY1 = current.y
                val controlX2 = (current.x + next.x) / 2f
                val controlY2 = next.y
                cubicTo(controlX1, controlY1, controlX2, controlY2, next.x, next.y)
            }
        }

        val fillPath = Path().apply {
            addPath(strokePath)
            lineTo(coordinates.last().x, size.height - verticalPadding)
            lineTo(coordinates.first().x, size.height - verticalPadding)
            close()
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    lineColor.copy(alpha = 0.34f),
                    secondaryColor.copy(alpha = 0.08f),
                    Color.Transparent
                )
            )
        )

        drawPath(
            path = strokePath,
            brush = Brush.horizontalGradient(listOf(secondaryColor, lineColor, ZenithNeonEmerald)),
            style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        coordinates.forEachIndexed { idx, pt ->
            if (idx == coordinates.lastIndex || idx % 2 == 0) {
                drawCircle(
                    color = ZenithDeepNavy,
                    radius = 5.5.dp.toPx(),
                    center = pt
                )
                drawCircle(
                    color = if (idx == coordinates.lastIndex) ZenithGold else lineColor,
                    radius = 3.8.dp.toPx(),
                    center = pt
                )
            }
        }
    }
}

/**
 * Circular Multi-Ring Life Architect Gauge rendered in pure Compose Canvas.
 */
@Composable
fun ZenithRadialScoreGauge(
    lifeScore: Int,
    habitProbability: Int,
    savingsRate: Int,
    modifier: Modifier = Modifier.size(132.dp)
) {
    val animatedLife by animateFloatAsState(
        targetValue = (lifeScore.coerceIn(0, 100) / 100f),
        animationSpec = tween(1000, easing = FastOutSlowInEasing),
        label = "life_arc"
    )
    val animatedHabit by animateFloatAsState(
        targetValue = (habitProbability.coerceIn(0, 100) / 100f),
        animationSpec = tween(1100, easing = FastOutSlowInEasing),
        label = "habit_arc"
    )
    val animatedSavings by animateFloatAsState(
        targetValue = (savingsRate.coerceIn(0, 100) / 100f),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "savings_arc"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .semantics {
                    contentDescription = "Zenith Life Score $lifeScore out of 100"
                }
        ) {
            val strokeOuter = 10.dp.toPx()
            val strokeMid = 8.dp.toPx()
            val strokeInner = 6.dp.toPx()

            // Outer Ring: Composite Life Score (Gold)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = strokeOuter, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(ZenithGold, ZenithNeonCyan, ZenithGold)),
                startAngle = 135f,
                sweepAngle = 270f * animatedLife,
                useCenter = false,
                style = Stroke(width = strokeOuter, cap = StrokeCap.Round)
            )

            // Middle Ring: Habit Consistency (Emerald)
            val inset1 = 16.dp.toPx()
            drawArc(
                color = Color.White.copy(alpha = 0.06f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(inset1, inset1),
                size = Size(size.width - inset1 * 2, size.height - inset1 * 2),
                style = Stroke(width = strokeMid, cap = StrokeCap.Round)
            )
            drawArc(
                color = ZenithNeonEmerald,
                startAngle = 135f,
                sweepAngle = 270f * animatedHabit,
                useCenter = false,
                topLeft = Offset(inset1, inset1),
                size = Size(size.width - inset1 * 2, size.height - inset1 * 2),
                style = Stroke(width = strokeMid, cap = StrokeCap.Round)
            )

            // Inner Ring: Savings Rate (Cyan)
            val inset2 = 30.dp.toPx()
            drawArc(
                color = Color.White.copy(alpha = 0.05f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(inset2, inset2),
                size = Size(size.width - inset2 * 2, size.height - inset2 * 2),
                style = Stroke(width = strokeInner, cap = StrokeCap.Round)
            )
            drawArc(
                color = ZenithNeonCyan,
                startAngle = 135f,
                sweepAngle = 270f * animatedSavings,
                useCenter = false,
                topLeft = Offset(inset2, inset2),
                size = Size(size.width - inset2 * 2, size.height - inset2 * 2),
                style = Stroke(width = strokeInner, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$lifeScore",
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = ZenithGold,
                    fontWeight = FontWeight.ExtraBold
                )
            )
            Text(
                text = "ZENITH",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 9.sp
                )
            )
        }
    }
}

/**
 * Custom Animated Pill Switch Button with Haptic Feedback.
 */
@Composable
fun ZenithNeonSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    label: String,
    subtitle: String? = null
) {
    val haptics = LocalHapticFeedback.current
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 24.dp else 2.dp,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "switch_thumb"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onCheckedChange(!checked)
            }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Box(
            modifier = Modifier
                .width(52.dp)
                .height(28.dp)
                .clip(CircleShape)
                .background(
                    if (checked) {
                        Brush.horizontalGradient(listOf(ZenithGold, ZenithNeonEmerald))
                    } else {
                        Brush.horizontalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.14f),
                                Color.White.copy(alpha = 0.08f)
                            )
                        )
                    }
                )
                .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (checked) ZenithDeepNavy else Color.White)
            )
        }
    }
}

/**
 * Custom Smooth Magic Indicator Bottom Navigation Bar with Sliding Neon Pill.
 */
@Composable
fun ZenithMagicIndicatorTabBar(
    tabs: List<String>,
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptics = LocalHapticFeedback.current
    var barSize by remember { mutableStateOf(IntSize.Zero) }
    val density = LocalDensity.current

    val tabWidthDp = remember(barSize, tabs.size) {
        if (barSize.width == 0 || tabs.isEmpty()) 0.dp
        else with(density) { (barSize.width / tabs.size).toDp() }
    }

    val indicatorOffset by animateDpAsState(
        targetValue = tabWidthDp * selectedIndex,
        animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing),
        label = "magic_tab_indicator"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(24.dp))
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        ZenithGold.copy(alpha = 0.45f),
                        ZenithNeonCyan.copy(alpha = 0.35f),
                        ZenithGold.copy(alpha = 0.45f)
                    )
                ),
                RoundedCornerShape(24.dp)
            ),
        color = ZenithMidnightSurface.copy(alpha = 0.95f),
        tonalElevation = 10.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .onGloballyPositioned { barSize = it.size }
        ) {
            if (tabWidthDp > 0.dp) {
                Box(
                    modifier = Modifier
                        .offset(x = indicatorOffset)
                        .width(tabWidthDp)
                        .fillMaxHeight()
                        .padding(6.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    ZenithGold.copy(alpha = 0.25f),
                                    ZenithNeonCyan.copy(alpha = 0.22f)
                                )
                            )
                        )
                        .border(
                            1.dp,
                            ZenithGold.copy(alpha = 0.7f),
                            RoundedCornerShape(18.dp)
                        )
                )
            }

            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = index == selectedIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onTabSelected(index)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                fontSize = if (isSelected) 12.sp else 11.sp,
                                color = if (isSelected) ZenithGold else Color.White.copy(alpha = 0.68f)
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
