package com.zenith.architect.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Executive Palette: Deep Navy, Sovereign Gold, Cyber Neon Emerald & Cyan
val ZenithDeepNavy = Color(0xFF070B19)
val ZenithMidnightSurface = Color(0xFF10172A)
val ZenithCardNavy = Color(0xFF162038)
val ZenithGold = Color(0xFFF5C451)
val ZenithGoldDeep = Color(0xFFD49B27)
val ZenithNeonCyan = Color(0xFF00F0FF)
val ZenithNeonEmerald = Color(0xFF10B981)
val ZenithCoralCrimson = Color(0xFFEF4444)
val ZenithTextPrimaryDark = Color(0xFFF8FAFC)
val ZenithTextSecondaryDark = Color(0xFF94A3B8)

val ZenithLightBackground = Color(0xFFF4F6FB)
val ZenithLightSurface = Color(0xFFFFFFFF)
val ZenithLightTextPrimary = Color(0xFF0F172A)
val ZenithLightTextSecondary = Color(0xFF475569)

private val ZenithDarkScheme = darkColorScheme(
    primary = ZenithGold,
    onPrimary = ZenithDeepNavy,
    secondary = ZenithNeonCyan,
    onSecondary = ZenithDeepNavy,
    tertiary = ZenithNeonEmerald,
    background = ZenithDeepNavy,
    onBackground = ZenithTextPrimaryDark,
    surface = ZenithMidnightSurface,
    onSurface = ZenithTextPrimaryDark,
    surfaceVariant = ZenithCardNavy,
    onSurfaceVariant = ZenithTextSecondaryDark,
    error = ZenithCoralCrimson
)

private val ZenithLightScheme = lightColorScheme(
    primary = ZenithGoldDeep,
    onPrimary = Color.White,
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    tertiary = ZenithNeonEmerald,
    background = ZenithLightBackground,
    onBackground = ZenithLightTextPrimary,
    surface = ZenithLightSurface,
    onSurface = ZenithLightTextPrimary,
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = ZenithLightTextSecondary,
    error = ZenithCoralCrimson
)

val ZenithTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 34.sp,
        lineHeight = 40.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        lineHeight = 25.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 15.sp,
        letterSpacing = 0.4.sp
    )
)

@Composable
fun Zenith360Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ZenithDarkScheme else ZenithLightScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = ZenithTypography,
        content = content
    )
}
