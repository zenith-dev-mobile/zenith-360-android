package com.zenith.architect.pro.data.repository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.zenith.architect.pro.data.local.HabitEntity
import com.zenith.architect.pro.data.local.TransactionEntity
import com.zenith.architect.pro.data.local.WellnessLogEntity
import com.zenith.architect.pro.data.local.ZenithDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ZenithRepository @Inject constructor(
    private val dao: ZenithDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = dao.observeAllTransactions()
    val totalIncome: Flow<Double> = dao.observeTotalIncome()
    val totalExpense: Flow<Double> = dao.observeTotalExpense()
    val allHabits: Flow<List<HabitEntity>> = dao.observeAllHabits()
    val recentWellnessLogs: Flow<List<WellnessLogEntity>> = dao.observeRecentWellnessLogs()

    fun getPagedTransactions(): Flow<PagingData<TransactionEntity>> {
        return Pager(
            config = PagingConfig(pageSize = 20, enablePlaceholders = false),
            pagingSourceFactory = { dao.pagingTransactions() }
        ).flow
    }

    suspend fun addTransaction(
        title: String,
        amount: Double,
        isIncome: Boolean,
        category: String,
        notes: String
    ) = withContext(Dispatchers.IO) {
        val cleanTitle = title.trim().ifEmpty { if (isIncome) "Income Stream" else "Strategic Expense" }
        val validAmount = amount.coerceAtLeast(0.01)
        dao.insertTransaction(
            TransactionEntity(
                title = cleanTitle,
                amount = validAmount,
                isIncome = isIncome,
                category = category.trim().ifEmpty { "General" },
                notes = notes.trim()
            )
        )
    }

    suspend fun deleteTransaction(entity: TransactionEntity) = withContext(Dispatchers.IO) {
        dao.deleteTransaction(entity)
    }

    suspend fun addHabit(
        title: String,
        category: String,
        targetDaysPerWeek: Int
    ) = withContext(Dispatchers.IO) {
        val cleanTitle = title.trim().ifEmpty { "Keystone Habit" }
        dao.insertHabit(
            HabitEntity(
                title = cleanTitle,
                category = category.trim().ifEmpty { "Mastery" },
                targetDaysPerWeek = targetDaysPerWeek.coerceIn(1, 7),
                currentStreak = 0,
                bestStreak = 0,
                completedToday = false,
                completionRate30d = 0.0f,
                lastCompletedEpochDay = 0L
            )
        )
    }

    suspend fun toggleHabitCompletion(habit: HabitEntity) = withContext(Dispatchers.IO) {
        val todayEpochDay = LocalDate.now().toEpochDay()
        val nowCompleted = !habit.completedToday
        val newStreak = if (nowCompleted) {
            habit.currentStreak + 1
        } else {
            (habit.currentStreak - 1).coerceAtLeast(0)
        }
        val newBest = maxOf(habit.bestStreak, newStreak)
        val updatedRate = if (nowCompleted) {
            (habit.completionRate30d * 0.9f + 0.1f).coerceIn(0.05f, 1.0f)
        } else {
            (habit.completionRate30d * 0.9f).coerceIn(0.0f, 1.0f)
        }
        dao.updateHabit(
            habit.copy(
                completedToday = nowCompleted,
                currentStreak = newStreak,
                bestStreak = newBest,
                completionRate30d = updatedRate,
                lastCompletedEpochDay = if (nowCompleted) todayEpochDay else habit.lastCompletedEpochDay
            )
        )
    }

    suspend fun deleteHabit(habit: HabitEntity) = withContext(Dispatchers.IO) {
        dao.deleteHabit(habit)
    }

    suspend fun addWellnessLog(
        moodScore: Int,
        energyScore: Int,
        focusMinutes: Int,
        sleepHours: Float,
        gratitudeReflection: String
    ) = withContext(Dispatchers.IO) {
        dao.insertWellnessLog(
            WellnessLogEntity(
                moodScore = moodScore.coerceIn(1, 10),
                energyScore = energyScore.coerceIn(1, 10),
                focusMinutes = focusMinutes.coerceIn(0, 1440),
                sleepHours = sleepHours.coerceIn(0f, 24f),
                gratitudeReflection = gratitudeReflection.trim().ifEmpty { "Focused on deliberate daily compounding." }
            )
        )
    }

    /**
     * Seeds realistic initial data on very first launch so charts, forecasts, and streaks
     * render immediately out-of-the-box without requiring empty-state setup.
     */
    suspend fun ensureInitialSeedData() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L

        if (dao.countTransactions() == 0) {
            val initialTransactions = listOf(
                TransactionEntity(
                    title = "Primary Software Engineering Retainer",
                    amount = 6400.00,
                    isIncome = true,
                    category = "Salary & Consulting",
                    notes = "Monthly architecture contract deposit",
                    timestampEpochMs = now - 6 * dayMs
                ),
                TransactionEntity(
                    title = "Global Index ETF Automated Allocation",
                    amount = 1850.00,
                    isIncome = false,
                    category = "Investments",
                    notes = "Long-term compounding portfolio contribution",
                    timestampEpochMs = now - 5 * dayMs
                ),
                TransactionEntity(
                    title = "Digital SaaS Product Royalties",
                    amount = 1120.00,
                    isIncome = true,
                    category = "Passive Income",
                    notes = "Automated recurring Play Store & SaaS revenue",
                    timestampEpochMs = now - 4 * dayMs
                ),
                TransactionEntity(
                    title = "Executive Residence & Utilities",
                    amount = 1420.00,
                    isIncome = false,
                    category = "Housing",
                    notes = "Fixed monthly living allocation",
                    timestampEpochMs = now - 3 * dayMs
                ),
                TransactionEntity(
                    title = "High-Protein Nutrition & Bio-Health",
                    amount = 410.00,
                    isIncome = false,
                    category = "Wellness",
                    notes = "Whole foods and longevity supplementation",
                    timestampEpochMs = now - 2 * dayMs
                ),
                TransactionEntity(
                    title = "Cloud Infrastructure & AI Compute",
                    amount = 145.00,
                    isIncome = false,
                    category = "Technology",
                    notes = "Development tooling and server nodes",
                    timestampEpochMs = now - 1 * dayMs
                )
            )
            initialTransactions.forEach { dao.insertTransaction(it) }
        }

        if (dao.countHabits() == 0) {
            val today = LocalDate.now().toEpochDay()
            val initialHabits = listOf(
                HabitEntity(
                    title = "90-Minute Deep Architecture Flow",
                    category = "Cognitive Mastery",
                    targetDaysPerWeek = 6,
                    currentStreak = 18,
                    bestStreak = 24,
                    completedToday = true,
                    completionRate30d = 0.90f,
                    lastCompletedEpochDay = today
                ),
                HabitEntity(
                    title = "Zero-Impulse Capital Audit",
                    category = "Wealth Discipline",
                    targetDaysPerWeek = 7,
                    currentStreak = 14,
                    bestStreak = 19,
                    completedToday = true,
                    completionRate30d = 0.86f,
                    lastCompletedEpochDay = today
                ),
                HabitEntity(
                    title = "Zone-2 Cardiovascular & Strength Training",
                    category = "Longevity",
                    targetDaysPerWeek = 5,
                    currentStreak = 9,
                    bestStreak = 15,
                    completedToday = false,
                    completionRate30d = 0.80f,
                    lastCompletedEpochDay = today - 1
                ),
                HabitEntity(
                    title = "Evening Stoic & Gratitude Synthesis",
                    category = "Mindfulness",
                    targetDaysPerWeek = 7,
                    currentStreak = 21,
                    bestStreak = 21,
                    completedToday = false,
                    completionRate30d = 0.93f,
                    lastCompletedEpochDay = today - 1
                )
            )
            initialHabits.forEach { dao.insertHabit(it) }
        }

        if (dao.countWellnessLogs() == 0) {
            val initialLogs = listOf(
                WellnessLogEntity(
                    moodScore = 9,
                    energyScore = 8,
                    focusMinutes = 195,
                    sleepHours = 7.8f,
                    gratitudeReflection = "Shipped clean modular architecture and maintained 18-day deep work streak.",
                    timestampEpochMs = now - 3 * dayMs
                ),
                WellnessLogEntity(
                    moodScore = 8,
                    energyScore = 8,
                    focusMinutes = 165,
                    sleepHours = 7.5f,
                    gratitudeReflection = "Automated index allocation executed; zero discretionary waste.",
                    timestampEpochMs = now - 2 * dayMs
                ),
                WellnessLogEntity(
                    moodScore = 9,
                    energyScore = 9,
                    focusMinutes = 210,
                    sleepHours = 8.1f,
                    gratitudeReflection = "High mental clarity after morning cardiovascular conditioning.",
                    timestampEpochMs = now - 1 * dayMs
                )
            )
            initialLogs.forEach { dao.insertWellnessLog(it) }
        }
    }
}
