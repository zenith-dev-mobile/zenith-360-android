package com.zenith.architect.pro.data.local

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ZenithDao {

    // -------------------- WEALTH TRANSACTIONS --------------------
    @Query("SELECT * FROM wealth_transactions ORDER BY timestamp_epoch_ms DESC")
    fun observeAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM wealth_transactions ORDER BY timestamp_epoch_ms DESC")
    fun pagingTransactions(): PagingSource<Int, TransactionEntity>

    @Query("SELECT COALESCE(SUM(amount), 0.0) FROM wealth_transactions WHERE is_income = 1")
    fun observeTotalIncome(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0.0) FROM wealth_transactions WHERE is_income = 0")
    fun observeTotalExpense(): Flow<Double>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("SELECT COUNT(*) FROM wealth_transactions")
    suspend fun countTransactions(): Int

    // -------------------- HABIT ARCHITECT --------------------
    @Query("SELECT * FROM habits ORDER BY completed_today ASC, current_streak DESC")
    fun observeAllHabits(): Flow<List<HabitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("SELECT COUNT(*) FROM habits")
    suspend fun countHabits(): Int

    // -------------------- PSYCHOLOGICAL WELLNESS --------------------
    @Query("SELECT * FROM wellness_logs ORDER BY timestamp_epoch_ms DESC LIMIT 30")
    fun observeRecentWellnessLogs(): Flow<List<WellnessLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWellnessLog(log: WellnessLogEntity): Long

    @Query("SELECT COUNT(*) FROM wellness_logs")
    suspend fun countWellnessLogs(): Int
}
