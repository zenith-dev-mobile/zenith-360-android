package com.zenith.architect.pro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.zenith.architect.pro.ads.ZenithAdMobManager
import com.zenith.architect.pro.ui.screens.ZenithDashboardApp
import com.zenith.architect.pro.ui.theme.Zenith360Theme
import com.zenith.architect.pro.ui.viewmodel.ZenithViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: ZenithViewModel by viewModels()

    @Inject
    lateinit var adMobManager: ZenithAdMobManager

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // WorkManager daily notification worker checks permission gracefully
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        splashScreen.setKeepOnScreenCondition {
            !viewModel.uiState.value.isInitialized
        }

        requestNotificationPermissionIfNeeded()
        adMobManager.gatherConsentAndInitializeAds(this)

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            LaunchedEffect(uiState.preferences.isPrivacyShieldEnabled) {
                if (uiState.preferences.isPrivacyShieldEnabled) {
                    window.setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE
                    )
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            Zenith360Theme(darkTheme = uiState.preferences.isDarkMode) {
                ZenithDashboardApp(
                    uiState = uiState,
                    viewModel = viewModel,
                    adMobManager = adMobManager
                )
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
