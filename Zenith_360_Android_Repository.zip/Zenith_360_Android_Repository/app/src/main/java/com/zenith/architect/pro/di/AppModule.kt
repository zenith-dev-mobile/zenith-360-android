package com.zenith.architect.pro.di

import android.content.Context
import androidx.room.Room
import com.zenith.architect.pro.data.local.ZenithDao
import com.zenith.architect.pro.data.local.ZenithDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideZenithDatabase(
        @ApplicationContext context: Context
    ): ZenithDatabase {
        return Room.databaseBuilder(
            context,
            ZenithDatabase::class.java,
            ZenithDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideZenithDao(database: ZenithDatabase): ZenithDao {
        return database.zenithDao()
    }
}
