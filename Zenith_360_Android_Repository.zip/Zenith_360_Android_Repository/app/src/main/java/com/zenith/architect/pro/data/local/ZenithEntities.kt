package com.zenith.architect.pro.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "wealth_transactions",
    indices = [
        Index(value = ["timestamp_epoch_ms"]),
        Index(value = ["category"]),
        Index(value = ["is_income"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "amount")
    val amount: Double,

    @ColumnInfo(name = "is_income")
    val isIncome: Boolean,

    @ColumnInfo(name = "category")
    val category: String,

    @ColumnInfo(name = "notes")
    val notes: String,

    @ColumnInfo(name = "timestamp_epoch_ms")
    val timestampEpochMs: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "is_synced")
    val isSynced: Boolean = true
)

@Entity(
    tableName = "habits",
    indices = [
        Index(value = ["category"]),
        Index(value = ["current_streak"])
    ]
)
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "category")
    val category: String,

    @ColumnInfo(name = "target_days_per_week")
    val targetDaysPerWeek: Int,

    @ColumnInfo(name = "current_streak")
    val currentStreak: Int,

    @ColumnInfo(name = "best_streak")
    val bestStreak: Int,

    @ColumnInfo(name = "completed_today")
    val completedToday: Boolean,

    @ColumnInfo(name = "completion_rate_30d")
    val completionRate30d: Float,

    @ColumnInfo(name = "last_completed_epoch_day")
    val lastCompletedEpochDay: Long,

    @ColumnInfo(name = "reminder_hour")
    val reminderHour: Int = 8
)

@Entity(
    tableName = "wellness_logs",
    indices = [Index(value = ["timestamp_epoch_ms"])]
)
data class WellnessLogEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "mood_score")
    val moodScore: Int, // 1..10

    @ColumnInfo(name = "energy_score")
    val energyScore: Int, // 1..10

    @ColumnInfo(name = "focus_minutes")
    val focusMinutes: Int,

    @ColumnInfo(name = "sleep_hours")
    val sleepHours: Float,

    @ColumnInfo(name = "gratitude_reflection")
    val gratitudeReflection: String,

    @ColumnInfo(name = "timestamp_epoch_ms")
    val timestampEpochMs: Long = System.currentTimeMillis()
)
