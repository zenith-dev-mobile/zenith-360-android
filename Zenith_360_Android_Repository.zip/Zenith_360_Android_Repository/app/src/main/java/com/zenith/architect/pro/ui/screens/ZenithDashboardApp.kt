package com.zenith.architect.pro.ui.screens

import android.app.Activity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenith.architect.pro.ads.ZenithAdMobManager
import com.zenith.architect.pro.data.local.HabitEntity
import com.zenith.architect.pro.data.local.TransactionEntity
import com.zenith.architect.pro.ui.components.GlassmorphicCard
import com.zenith.architect.pro.ui.components.ZenithAdaptiveBannerBar
import com.zenith.architect.pro.ui.components.ZenithBezierTrendChart
import com.zenith.architect.pro.ui.components.ZenithCanvasLogo
import com.zenith.architect.pro.ui.components.ZenithCinematicSplashScreen
import com.zenith.architect.pro.ui.components.ZenithMagicIndicatorTabBar
import com.zenith.architect.pro.ui.components.ZenithNeonSwitch
import com.zenith.architect.pro.ui.components.ZenithRadialScoreGauge
import com.zenith.architect.pro.ui.theme.ZenithCoralCrimson
import com.zenith.architect.pro.ui.theme.ZenithDeepNavy
import com.zenith.architect.pro.ui.theme.ZenithGold
import com.zenith.architect.pro.ui.theme.ZenithNeonCyan
import com.zenith.architect.pro.ui.theme.ZenithNeonEmerald
import com.zenith.architect.pro.ui.viewmodel.TransactionSortOrder
import com.zenith.architect.pro.ui.viewmodel.ZenithUiState
import com.zenith.architect.pro.ui.viewmodel.ZenithViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ZenithDashboardApp(
    uiState: ZenithUiState,
    viewModel: ZenithViewModel,
    adMobManager: ZenithAdMobManager
) {
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var showAddTransactionDialog by rememberSaveable { mutableStateOf(false) }
    var showAddHabitDialog by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as? Activity

    if (showSplash) {
        ZenithCinematicSplashScreen(
            onSplashCompleted = { showSplash = false }
        )
        return
    }

    val tabs = listOf("Command", "Wealth", "Habits", "Wellness", "AI & Vault")
    val selectedTab = uiState.preferences.lastSelectedTabIndex.coerceIn(0, tabs.lastIndex)

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        topBar = {
            ZenithTopHeaderBar(
                greeting = uiState.aiForecast.adaptiveGreeting,
                netWorth = uiState.totalIncome - uiState.totalExpense,
                currency = uiState.preferences.currencySymbol
            )
        },
        floatingActionButton = {
            if (selectedTab == 1 || selectedTab == 2) {
                FloatingActionButton(
                    onClick = {
                        if (selectedTab == 1) showAddTransactionDialog = true
                        else showAddHabitDialog = true
                    },
                    containerColor = ZenithGold,
                    contentColor = ZenithDeepNavy,
                    shape = CircleShape
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add New Architect Record"
                    )
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                ZenithMagicIndicatorTabBar(
                    tabs = tabs,
                    selectedIndex = selectedTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
                ZenithAdaptiveBannerBar(adMobManager = adMobManager)
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            label = "main_tab_transition"
        ) { tabIndex ->
            when (tabIndex) {
                0 -> CommandCenterTab(uiState = uiState)
                1 -> WealthArchitectTab(
                    uiState = uiState,
                    onSearchChange = viewModel::updateSearchQuery,
                    onCategoryFilter = viewModel::updateCategoryFilter,
                    onSortChange = viewModel::updateSortOrder,
                    onDeleteTransaction = viewModel::deleteTransaction
                )
                2 -> HabitArchitectTab(
                    uiState = uiState,
                    onToggleHabit = { habit ->
                        viewModel.toggleHabitCompletion(habit) { completedCount ->
                            activity?.let {
                                adMobManager.showInterstitialAtNaturalPauseIfEligible(it, completedCount)
                            }
                        }
                    },
                    onDeleteHabit = viewModel::deleteHabit
                )
                3 -> WellnessLabTab(
                    uiState = uiState,
                    onLogWellness = { mood, energy, focus, sleep, reflection ->
                        viewModel.addWellnessLog(mood, energy, focus, sleep, reflection) { completedCount ->
                            activity?.let {
                                adMobManager.showInterstitialAtNaturalPauseIfEligible(it, completedCount)
                            }
                        }
                    }
                )
                4 -> AiVaultAndSettingsTab(
                    uiState = uiState,
                    onToggleDarkMode = viewModel::toggleDarkMode,
                    onTogglePrivacyShield = viewModel::togglePrivacyShield,
                    onSelectCurrency = viewModel::setCurrencySymbol,
                    onUnlockVipWithRewardedAd = {
                        if (activity != null) {
                            adMobManager.showRewardedAdToUnlockFeature(
                                activity = activity,
                                onRewardEarned = { viewModel.unlockVipForecast() },
                                onUnavailableOrDismissed = { viewModel.unlockVipForecast() }
                            )
                        } else {
                            viewModel.unlockVipForecast()
                        }
                    }
                )
            }
        }
    }

    if (showAddTransactionDialog) {
        AddTransactionModal(
            currencySymbol = uiState.preferences.currencySymbol,
            onDismiss = { showAddTransactionDialog = false },
            onSave = { title, amount, isIncome, category, notes ->
                viewModel.addTransaction(title, amount, isIncome, category, notes) { completedCount ->
                    activity?.let {
                        adMobManager.showInterstitialAtNaturalPauseIfEligible(it, completedCount)
                    }
                }
                showAddTransactionDialog = false
            }
        )
    }

    if (showAddHabitDialog) {
        AddHabitModal(
            onDismiss = { showAddHabitDialog = false },
            onSave = { title, category, days ->
                viewModel.addHabit(title, category, days) { completedCount ->
                    activity?.let {
                        adMobManager.showInterstitialAtNaturalPauseIfEligible(it, completedCount)
                    }
                }
                showAddHabitDialog = false
            }
        )
    }
}

@Composable
private fun ZenithTopHeaderBar(
    greeting: String,
    netWorth: Double,
    currency: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            ZenithCanvasLogo(modifier = Modifier.size(44.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "ZENITH 360",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = ZenithGold,
                        letterSpacing = 1.8.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                )
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "NET LIQUIDITY",
                style = MaterialTheme.typography.labelSmall,
                color = ZenithNeonCyan
            )
            Text(
                text = "$currency${String.format(Locale.US, "%,.2f", netWorth)}",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = if (netWorth >= 0) ZenithNeonEmerald else ZenithCoralCrimson,
                    fontWeight = FontWeight.ExtraBold
                )
            )
        }
    }
}

@Composable
private fun CommandCenterTab(uiState: ZenithUiState) {
    val currency = uiState.preferences.currencySymbol
    val forecast = uiState.aiForecast

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            GlassmorphicCard(accentBorderColor = ZenithGold.copy(alpha = 0.5f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = "HOLISTIC ARCHITECT MATRIX",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithNeonCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = forecast.keystoneInsight,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            MetricPill(label = "Habit AI", value = "${forecast.habitSuccessProbabilityPercent}%", color = ZenithNeonEmerald)
                            MetricPill(label = "Savings", value = "${forecast.savingsRatePercent}%", color = ZenithNeonCyan)
                            MetricPill(label = "Focus", value = String.format(Locale.US, "%.1f", forecast.cognitiveMomentumIndex), color = ZenithGold)
                        }
                    }
                    ZenithRadialScoreGauge(
                        lifeScore = forecast.zenithLifeScore,
                        habitProbability = forecast.habitSuccessProbabilityPercent,
                        savingsRate = forecast.savingsRatePercent
                    )
                }
            }
        }

        item {
            GlassmorphicCard(accentBorderColor = ZenithNeonCyan.copy(alpha = 0.45f)) {
                Text(
                    text = "12-MONTH COMPOUND WEALTH TRAJECTORY",
                    style = MaterialTheme.typography.labelSmall,
                    color = ZenithGold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "1-Year Projected Surplus: $currency${String.format(Locale.US, "%,.0f", forecast.projectedNetWorth1Year)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))
                ZenithBezierTrendChart(dataPoints = forecast.monthlyTrajectorySeries)
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GlassmorphicCard(
                    modifier = Modifier.weight(1f),
                    accentBorderColor = ZenithNeonEmerald.copy(alpha = 0.4f)
                ) {
                    Text("TOTAL INFLOW", style = MaterialTheme.typography.labelSmall, color = ZenithNeonEmerald)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$currency${String.format(Locale.US, "%,.2f", uiState.totalIncome)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                GlassmorphicCard(
                    modifier = Modifier.weight(1f),
                    accentBorderColor = ZenithCoralCrimson.copy(alpha = 0.4f)
                ) {
                    Text("TOTAL OUTFLOW", style = MaterialTheme.typography.labelSmall, color = ZenithCoralCrimson)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$currency${String.format(Locale.US, "%,.2f", uiState.totalExpense)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Text(
                text = "ACTIVE KEYSTONE STREAKS",
                style = MaterialTheme.typography.labelSmall,
                color = ZenithGold
            )
        }

        items(uiState.habits.take(3), key = { it.id }) { habit ->
            GlassmorphicCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(habit.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${habit.category} • Streak: ${habit.currentStreak}d (Best ${habit.bestStreak}d)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${(habit.completionRate30d * 100).toInt()}%",
                        style = MaterialTheme.typography.titleMedium.copy(color = ZenithNeonEmerald)
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricPill(label: String, value: String, color: Color) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(color = color, fontWeight = FontWeight.Bold))
    }
}

@Composable
private fun WealthArchitectTab(
    uiState: ZenithUiState,
    onSearchChange: (String) -> Unit,
    onCategoryFilter: (String) -> Unit,
    onSortChange: (TransactionSortOrder) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit
) {
    val currency = uiState.preferences.currencySymbol
    val categories = listOf("All", "Salary & Consulting", "Investments", "Passive Income", "Housing", "Wellness", "Technology")
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.US) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search transactions, categories, or notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val selected = uiState.selectedCategoryFilter.equals(category, ignoreCase = true)
                    FilterChip(
                        selected = selected,
                        onClick = { onCategoryFilter(category) },
                        label = { Text(category) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ZenithGold.copy(alpha = 0.25f),
                            selectedLabelColor = ZenithGold
                        )
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LEDGER (${uiState.filteredTransactions.size} RECORDS)",
                    style = MaterialTheme.typography.labelSmall,
                    color = ZenithNeonCyan
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TransactionSortOrder.entries.forEach { order ->
                        val active = uiState.sortOrder == order
                        Text(
                            text = when (order) {
                                TransactionSortOrder.NEWEST_FIRST -> "Newest"
                                TransactionSortOrder.HIGHEST_AMOUNT -> "Amount"
                                TransactionSortOrder.CATEGORY_AZ -> "A-Z"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (active) ZenithGold else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) ZenithGold.copy(alpha = 0.16f) else Color.Transparent)
                                .clickable { onSortChange(order) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        items(uiState.filteredTransactions, key = { it.id }) { tx ->
            GlassmorphicCard(
                accentBorderColor = if (tx.isIncome) ZenithNeonEmerald.copy(alpha = 0.35f)
                else ZenithCoralCrimson.copy(alpha = 0.3f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(tx.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${tx.category} • ${dateFormat.format(Date(tx.timestampEpochMs))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithNeonCyan
                        )
                        if (tx.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tx.notes,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${if (tx.isIncome) "+" else "-"}$currency${String.format(Locale.US, "%,.2f", tx.amount)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = if (tx.isIncome) ZenithNeonEmerald else ZenithCoralCrimson,
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                        IconButton(onClick = { onDeleteTransaction(tx) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Transaction",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HabitArchitectTab(
    uiState: ZenithUiState,
    onToggleHabit: (HabitEntity) -> Unit,
    onDeleteHabit: (HabitEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            GlassmorphicCard(accentBorderColor = ZenithNeonEmerald.copy(alpha = 0.45f)) {
                Text("NEURAL HABIT ARCHITECT", style = MaterialTheme.typography.labelSmall, color = ZenithNeonEmerald)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "30-Day Adherence Probability: ${uiState.aiForecast.habitSuccessProbabilityPercent}%",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "Tap the completion emblem on any keystone habit below to compound your daily streak.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(uiState.habits, key = { it.id }) { habit ->
            GlassmorphicCard(
                accentBorderColor = if (habit.completedToday) ZenithNeonEmerald.copy(alpha = 0.6f)
                else ZenithGold.copy(alpha = 0.28f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { onToggleHabit(habit) }) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Toggle Habit Completion",
                            tint = if (habit.completedToday) ZenithNeonEmerald else Color.White.copy(alpha = 0.28f),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(habit.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${habit.category} • Target ${habit.targetDaysPerWeek}d/wk",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithNeonCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Current Streak: ${habit.currentStreak} days • Best: ${habit.bestStreak} days",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { onDeleteHabit(habit) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Habit",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WellnessLabTab(
    uiState: ZenithUiState,
    onLogWellness: (Int, Int, Int, Float, String) -> Unit
) {
    var mood by rememberSaveable { mutableFloatStateOf(9f) }
    var energy by rememberSaveable { mutableFloatStateOf(8f) }
    var focusMinutesText by rememberSaveable { mutableStateOf("180") }
    var sleepHoursText by rememberSaveable { mutableStateOf("7.8") }
    var reflectionText by rememberSaveable { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassmorphicCard(accentBorderColor = ZenithNeonCyan.copy(alpha = 0.45f)) {
                Text("PSYCHOLOGICAL & COGNITIVE TELEMETRY", style = MaterialTheme.typography.labelSmall, color = ZenithNeonCyan)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Cognitive Momentum Index: ${String.format(Locale.US, "%.1f", uiState.aiForecast.cognitiveMomentumIndex)} / 10.0",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text("Mood Clarity (${mood.toInt()}/10)", style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = mood,
                    onValueChange = { mood = it },
                    valueRange = 1f..10f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = ZenithGold, activeTrackColor = ZenithGold)
                )

                Text("Bio-Energy Reserve (${energy.toInt()}/10)", style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = energy,
                    onValueChange = { energy = it },
                    valueRange = 1f..10f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = ZenithNeonEmerald, activeTrackColor = ZenithNeonEmerald)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = focusMinutesText,
                        onValueChange = { focusMinutesText = it },
                        label = { Text("Deep Work (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sleepHoursText,
                        onValueChange = { sleepHoursText = it },
                        label = { Text("Sleep (hrs)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = reflectionText,
                    onValueChange = { reflectionText = it },
                    label = { Text("Stoic & Gratitude Reflection") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val focusMins = focusMinutesText.toIntOrNull() ?: 120
                        val sleepHrs = sleepHoursText.toFloatOrNull() ?: 7.5f
                        onLogWellness(mood.toInt(), energy.toInt(), focusMins, sleepHrs, reflectionText)
                        reflectionText = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ZenithGold, contentColor = ZenithDeepNavy)
                ) {
                    Text("Commit Daily Cognitive Log", fontWeight = FontWeight.Bold)
                }
            }
        }

        items(uiState.wellnessLogs, key = { it.id }) { log ->
            GlassmorphicCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Mood ${log.moodScore}/10 • Energy ${log.energyScore}/10",
                        style = MaterialTheme.typography.titleMedium,
                        color = ZenithGold
                    )
                    Text(
                        text = "${log.focusMinutes}m focus • ${log.sleepHours}h sleep",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenithNeonCyan
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = log.gratitudeReflection,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun AiVaultAndSettingsTab(
    uiState: ZenithUiState,
    onToggleDarkMode: (Boolean) -> Unit,
    onTogglePrivacyShield: (Boolean) -> Unit,
    onSelectCurrency: (String) -> Unit,
    onUnlockVipWithRewardedAd: () -> Unit
) {
    val currency = uiState.preferences.currencySymbol
    val forecast = uiState.aiForecast
    val sec = uiState.securityReport

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassmorphicCard(accentBorderColor = ZenithGold.copy(alpha = 0.6f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (uiState.preferences.isVipForecastUnlocked) Icons.Default.Star else Icons.Default.Lock,
                        contentDescription = "VIP Century Wealth Projections",
                        tint = ZenithGold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "5-YEAR & 10-YEAR AI WEALTH MONTE CARLO",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenithGold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                if (uiState.preferences.isVipForecastUnlocked) {
                    Text(
                        text = "5-Year Compound Projection: $currency${String.format(Locale.US, "%,.0f", forecast.projectedNetWorth5Years)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = ZenithNeonEmerald
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "10-Year Financial Independence Target: $currency${String.format(Locale.US, "%,.0f", forecast.projectedNetWorth10Years)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = ZenithNeonCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Calculated on-device using 7.5% real annualized compounding and your current monthly savings velocity.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "Unlock your 5-Year & 10-Year Compounding Wealth Matrix by viewing a brief Rewarded Sponsor message.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onUnlockVipWithRewardedAd,
                        colors = ButtonDefaults.buttonColors(containerColor = ZenithGold, contentColor = ZenithDeepNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Watch Rewarded Ad to Unlock Decade Forecast", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            GlassmorphicCard(accentBorderColor = ZenithNeonCyan.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = "Security Audit", tint = ZenithNeonCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ZERO-TRUST SECURITY & ANTI-TAMPER VAULT",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenithNeonCyan
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Device Integrity Score: ${sec.integrityScore}/100",
                    style = MaterialTheme.typography.titleLarge,
                    color = ZenithNeonEmerald
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• AES-256-GCM EncryptedSharedPreferences Vault: ${if (sec.encryptedVaultActive) "ACTIVE" else "STANDBY"}\n" +
                            "• Root / Su Binary Tamper Check: ${if (sec.isRooted) "DETECTED" else "CLEAN"}\n" +
                            "• Package Signature Binding (com.zenith.architect.pro): ${if (sec.isPackageValid) "VERIFIED" else "MISMATCH"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            GlassmorphicCard {
                Text("EXECUTIVE PREFERENCES", style = MaterialTheme.typography.labelSmall, color = ZenithGold)
                Spacer(modifier = Modifier.height(8.dp))
                ZenithNeonSwitch(
                    checked = uiState.preferences.isDarkMode,
                    onCheckedChange = onToggleDarkMode,
                    label = "Deep Navy Sovereign Dark Mode",
                    subtitle = "Toggle between Deep Navy Gold and Daylight Executive theme"
                )
                ZenithNeonSwitch(
                    checked = uiState.preferences.isPrivacyShieldEnabled,
                    onCheckedChange = onTogglePrivacyShield,
                    label = "FLAG_SECURE Screen-Recording Shield",
                    subtitle = "Blocks screenshots and screen recording on financial screens"
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Primary Currency Symbol", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("$", "€", "£", "¥", "₹", "ETB ").forEach { sym ->
                        val active = currency == sym
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) ZenithGold else Color.White.copy(alpha = 0.08f))
                                .border(1.dp, ZenithGold.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .clickable { onSelectCurrency(sym) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = sym.trim(),
                                color = if (active) ZenithDeepNavy else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddTransactionModal(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (String, Double, Boolean, String, String) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var amountText by rememberSaveable { mutableStateOf("") }
    var isIncome by rememberSaveable { mutableStateOf(true) }
    var category by rememberSaveable { mutableStateOf("Investments") }
    var notes by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Wealth Transaction") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ZenithNeonSwitch(
                    checked = isIncome,
                    onCheckedChange = { isIncome = it },
                    label = if (isIncome) "Income / Capital Inflow" else "Expense / Capital Outflow"
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Strategic Notes") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 100.0
                    onSave(title, amt, isIncome, category, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ZenithGold, contentColor = ZenithDeepNavy)
            ) {
                Text("Save Entry", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun AddHabitModal(
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("Cognitive Mastery") }
    var targetDays by rememberSaveable { mutableIntStateOf(6) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Architect New Keystone Habit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Habit Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Domain (e.g., Wealth, Longevity)") },
                    singleLine = true
                )
                Text("Target Frequency: $targetDays days / week")
                Slider(
                    value = targetDays.toFloat(),
                    onValueChange = { targetDays = it.toInt() },
                    valueRange = 1f..7f,
                    steps = 5
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(title, category, targetDays) },
                colors = ButtonDefaults.buttonColors(containerColor = ZenithGold, contentColor = ZenithDeepNavy)
            ) {
                Text("Create Habit", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
