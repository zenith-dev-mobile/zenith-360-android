package com.zenith.architect.pro.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.zenith.architect.pro.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ZenithAdMobManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "ZenithAdMobManager"
        const val ADMOB_APP_ID = BuildConfig.ADMOB_APP_ID
        const val BANNER_UNIT_ID = BuildConfig.ADMOB_BANNER_ID
        const val INTERSTITIAL_UNIT_ID = BuildConfig.ADMOB_INTERSTITIAL_ID
        const val REWARDED_UNIT_ID = BuildConfig.ADMOB_REWARDED_ID

        // Anti-intrusive cooldown: minimum 90 seconds between interstitial impressions
        private const val INTERSTITIAL_COOLDOWN_MS = 90_000L
    }

    private val adScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val isMobileAdsInitialized = AtomicBoolean(false)
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var lastInterstitialShownTimestampMs: Long = 0L

    private val _isRewardedAdReady = MutableStateFlow(false)
    val isRewardedAdReady: StateFlow<Boolean> = _isRewardedAdReady.asStateFlow()

    private val _canRequestAdsState = MutableStateFlow(false)
    val canRequestAdsState: StateFlow<Boolean> = _canRequestAdsState.asStateFlow()

    /**
     * Requests GDPR / CCPA / UMP consent safely on Activity start and initializes MobileAds
     * only when allowed and online.
     */
    fun gatherConsentAndInitializeAds(activity: Activity) {
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        val consentInformation: ConsentInformation = UserMessagingPlatform.getConsentInformation(activity)
        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(TAG, "UMP Consent form note: ${formError.message}")
                    }
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsSdk()
                    }
                }
            },
            { requestError ->
                Log.w(TAG, "UMP Consent update fallback: ${requestError.message}")
                if (consentInformation.canRequestAds()) {
                    initializeMobileAdsSdk()
                } else {
                    // Initialize in non-personalized / safe configuration when UMP isn't required in region
                    initializeMobileAdsSdk()
                }
            }
        )

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsSdk()
        }
    }

    private fun initializeMobileAdsSdk() {
        if (!isNetworkAvailable()) return
        if (isMobileAdsInitialized.compareAndSet(false, true)) {
            val requestConfig = RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_PG)
                .build()
            MobileAds.setRequestConfiguration(requestConfig)

            adScope.launch(Dispatchers.IO) {
                MobileAds.initialize(context) {
                    adScope.launch(Dispatchers.Main) {
                        _canRequestAdsState.value = true
                        preloadInterstitialAd()
                        preloadRewardedAd()
                    }
                }
            }
        }
    }

    fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun calculateAdaptiveBannerAdSize(context: Context): AdSize {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val outMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(outMetrics)
        val density = outMetrics.density
        val adWidthPixels = outMetrics.widthPixels.toFloat()
        val adWidth = (adWidthPixels / density).toInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth)
    }

    fun preloadInterstitialAd() {
        if (!isNetworkAvailable() || interstitialAd != null) return
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            INTERSTITIAL_UNIT_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    Log.d(TAG, "Interstitial failed to load silently: ${error.message}")
                }
            }
        )
    }

    /**
     * Policy-compliant natural pause trigger: only shows an interstitial after every 3rd completed user task
     * and enforces a strict 90-second cooldown.
     */
    fun showInterstitialAtNaturalPauseIfEligible(
        activity: Activity,
        completedTaskCount: Int,
        onFinished: () -> Unit = {}
    ) {
        val now = System.currentTimeMillis()
        val cooldownElapsed = (now - lastInterstitialShownTimestampMs) >= INTERSTITIAL_COOLDOWN_MS
        val eligibleMilestone = completedTaskCount > 0 && (completedTaskCount % 3 == 0)
        val readyAd = interstitialAd

        if (!eligibleMilestone || !cooldownElapsed || readyAd == null || activity.isFinishing) {
            if (readyAd == null) preloadInterstitialAd()
            onFinished()
            return
        }

        readyAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                preloadInterstitialAd()
                onFinished()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                interstitialAd = null
                preloadInterstitialAd()
                onFinished()
            }

            override fun onAdShowedFullScreenContent() {
                lastInterstitialShownTimestampMs = System.currentTimeMillis()
            }
        }
        readyAd.show(activity)
    }

    fun preloadRewardedAd() {
        if (!isNetworkAvailable() || rewardedAd != null) return
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            REWARDED_UNIT_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    _isRewardedAdReady.value = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    _isRewardedAdReady.value = false
                    Log.d(TAG, "Rewarded ad failed to load silently: ${error.message}")
                }
            }
        )
    }

    fun showRewardedAdToUnlockFeature(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onUnavailableOrDismissed: () -> Unit = {}
    ) {
        val readyReward = rewardedAd
        if (readyReward == null || activity.isFinishing) {
            preloadRewardedAd()
            // Graceful offline/unfilled fallback so user is never stuck
            onUnavailableOrDismissed()
            return
        }

        var rewardGranted = false
        readyReward.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                _isRewardedAdReady.value = false
                preloadRewardedAd()
                if (!rewardGranted) {
                    onUnavailableOrDismissed()
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                rewardedAd = null
                _isRewardedAdReady.value = false
                preloadRewardedAd()
                onUnavailableOrDismissed()
            }
        }

        readyReward.show(activity) {
            rewardGranted = true
            onRewardEarned()
        }
    }
}
