package com.zenith.architect.pro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        TransactionEntity::class,
        HabitEntity::class,
        WellnessLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ZenithDatabase : RoomDatabase() {
    abstract fun zenithDao(): ZenithDao

    companion object {
        const val DATABASE_NAME = "zenith_360_architect.db"
    }
}
