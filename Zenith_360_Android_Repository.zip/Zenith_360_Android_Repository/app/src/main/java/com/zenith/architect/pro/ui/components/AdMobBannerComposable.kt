package com.zenith.architect.pro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.zenith.architect.pro.ads.ZenithAdMobManager
import com.zenith.architect.pro.ui.theme.ZenithDeepNavy

/**
 * Policy-Compliant Fixed Bottom Adaptive Banner Ad Container.
 * Includes a dedicated safe-zone buffer above the banner to prevent accidental clicks
 * and handles offline/unfilled states silently without layout jumps.
 */
@Composable
fun ZenithAdaptiveBannerBar(
    adMobManager: ZenithAdMobManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val canRequestAds by adMobManager.canRequestAdsState.collectAsState()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(ZenithDeepNavy)
            .navigationBarsPadding()
            .padding(top = 6.dp, bottom = 2.dp)
            .heightIn(min = 52.dp),
        contentAlignment = Alignment.Center
    ) {
        if (canRequestAds && adMobManager.isNetworkAvailable()) {
            val adView = remember(context) {
                AdView(context).apply {
                    adUnitId = ZenithAdMobManager.BANNER_UNIT_ID
                    setAdSize(adMobManager.calculateAdaptiveBannerAdSize(context))
                    adListener = object : AdListener() {
                        override fun onAdFailedToLoad(error: LoadAdError) {
                            // Handled silently per Google Play & AdMob quality guidelines
                        }
                    }
                    loadAd(AdRequest.Builder().build())
                }
            }

            DisposableEffect(adView) {
                onDispose {
                    adView.destroy()
                }
            }

            AndroidView(
                factory = { adView },
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Text(
                text = "Zenith 360 • Offline-First Encrypted Architecture",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}
