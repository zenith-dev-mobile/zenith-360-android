package com.zenith.architect.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zenith.architect.pro.data.local.HabitEntity
import com.zenith.architect.pro.data.local.TransactionEntity
import com.zenith.architect.pro.data.local.WellnessLogEntity
import com.zenith.architect.pro.data.preferences.UserPreferencesRepository
import com.zenith.architect.pro.data.preferences.ZenithUserPreferences
import com.zenith.architect.pro.data.repository.ZenithRepository
import com.zenith.architect.pro.domain.ml.ZenithAiForecast
import com.zenith.architect.pro.domain.ml.ZenithPredictiveEngine
import com.zenith.architect.pro.security.DeviceSecurityReport
import com.zenith.architect.pro.security.SecurityAuditManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class TransactionSortOrder {
    NEWEST_FIRST,
    HIGHEST_AMOUNT,
    CATEGORY_AZ
}

data class ZenithUiState(
    val isInitialized: Boolean = false,
    val preferences: ZenithUserPreferences = ZenithUserPreferences(),
    val transactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val habits: List<HabitEntity> = emptyList(),
    val wellnessLogs: List<WellnessLogEntity> = emptyList(),
    val aiForecast: ZenithAiForecast = ZenithAiForecast(
        adaptiveGreeting = "Welcome, Architect",
        zenithLifeScore = 88,
        habitSuccessProbabilityPercent = 85,
        savingsRatePercent = 42,
        projectedNetWorth1Year = 45000.0,
        projectedNetWorth5Years = 270000.0,
        projectedNetWorth10Years = 665000.0,
        cognitiveMomentumIndex = 8.6f,
        keystoneInsight = "Initializing on-device neural wealth & habit engine...",
        monthlyTrajectorySeries = listOf(3500f, 7100f, 10800f, 14600f, 18500f, 22600f)
    ),
    val securityReport: DeviceSecurityReport = DeviceSecurityReport(
        isRooted = false,
        isEmulator = false,
        isDebuggable = false,
        isDebuggerAttached = false,
        isPackageValid = true,
        encryptedVaultActive = true
    ),
    val searchQuery: String = "",
    val selectedCategoryFilter: String = "All",
    val sortOrder: TransactionSortOrder = TransactionSortOrder.NEWEST_FIRST
)

@HiltViewModel
class ZenithViewModel @Inject constructor(
    private val repository: ZenithRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val predictiveEngine: ZenithPredictiveEngine,
    private val securityAuditManager: SecurityAuditManager
) : ViewModel() {

    private val searchQueryFlow = MutableStateFlow("")
    private val categoryFilterFlow = MutableStateFlow("All")
    private val sortOrderFlow = MutableStateFlow(TransactionSortOrder.NEWEST_FIRST)

    private val safeExceptionHandler = CoroutineExceptionHandler { _, _ ->
        // Prevent any background state mutation failure from crashing the UI thread
    }

    init {
        viewModelScope.launch(safeExceptionHandler) {
            repository.ensureInitialSeedData()
        }
    }

    private val baseDataFlow = combine(
        preferencesRepository.userPreferencesFlow,
        repository.allTransactions,
        repository.totalIncome,
        repository.totalExpense,
        repository.allHabits
    ) { prefs, txs, income, expense, habits ->
         Quintuple(prefs, txs, income, expense, habits)
    }

    val uiState: StateFlow<ZenithUiState> = combine(
        baseDataFlow,
        repository.recentWellnessLogs,
        searchQueryFlow,
        categoryFilterFlow,
        sortOrderFlow
    ) { base, wellnessLogs, query, categoryFilter, sortOrder ->
        val (prefs, txs, income, expense, habits) = base

        val filteredTxs = txs
            .filter { tx ->
                val matchesQuery = query.isBlank() ||
                        tx.title.contains(query, ignoreCase = true) ||
                        tx.category.contains(query, ignoreCase = true) ||
                        tx.notes.contains(query, ignoreCase = true)
                val matchesCat = categoryFilter == "All" ||
                        tx.category.equals(categoryFilter, ignoreCase = true)
                matchesQuery && matchesCat
            }
            .let { list ->
                when (sortOrder) {
                    TransactionSortOrder.NEWEST_FIRST -> list.sortedByDescending { it.timestampEpochMs }
                    TransactionSortOrder.HIGHEST_AMOUNT -> list.sortedByDescending { it.amount }
                    TransactionSortOrder.CATEGORY_AZ -> list.sortedBy { it.category.lowercase() }
                }
            }

        val forecast = predictiveEngine.computeHolisticForecast(
            transactions = txs,
            habits = habits,
            wellnessLogs = wellnessLogs,
            monthlySavingsGoal = prefs.monthlySavingsGoal
        )

        ZenithUiState(
            isInitialized = true,
            preferences = prefs,
            transactions = txs,
            filteredTransactions = filteredTxs,
            totalIncome = income,
            totalExpense = expense,
            habits = habits,
            wellnessLogs = wellnessLogs,
            aiForecast = forecast,
            securityReport = securityAuditManager.performSecurityAudit(),
            searchQuery = query,
            selectedCategoryFilter = categoryFilter,
            sortOrder = sortOrder
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ZenithUiState()
    )

    fun updateSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun updateCategoryFilter(category: String) {
        categoryFilterFlow.value = category
    }

    fun updateSortOrder(order: TransactionSortOrder) {
        sortOrderFlow.value = order
    }

    fun selectTab(index: Int) {
        viewModelScope.launch(safeExceptionHandler) {
            preferencesRepository.setLastSelectedTab(index)
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch(safeExceptionHandler) {
            preferencesRepository.setDarkMode(enabled)
        }
    }

    fun togglePrivacyShield(enabled: Boolean) {
        viewModelScope.launch(safeExceptionHandler) {
            preferencesRepository.setPrivacyShield(enabled)
        }
    }

    fun unlockVipForecast() {
        viewModelScope.launch(safeExceptionHandler) {
            preferencesRepository.setVipForecastUnlocked(true)
        }
    }

    fun setCurrencySymbol(symbol: String) {
        viewModelScope.launch(safeExceptionHandler) {
            preferencesRepository.setCurrencySymbol(symbol)
        }
    }

    fun addTransaction(
        title: String,
        amount: Double,
        isIncome: Boolean,
        category: String,
        notes: String,
        onCompletedCountUpdated: (Int) -> Unit = {}
    ) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.addTransaction(title, amount, isIncome, category, notes)
            val count = preferencesRepository.incrementCompletedTasks()
            onCompletedCountUpdated(count)
        }
    }

    fun deleteTransaction(entity: TransactionEntity) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.deleteTransaction(entity)
        }
    }

    fun addHabit(
        title: String,
        category: String,
        targetDaysPerWeek: Int,
        onCompletedCountUpdated: (Int) -> Unit = {}
    ) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.addHabit(title, category, targetDaysPerWeek)
            val count = preferencesRepository.incrementCompletedTasks()
            onCompletedCountUpdated(count)
        }
    }

    fun toggleHabitCompletion(
        habit: HabitEntity,
        onCompletedCountUpdated: (Int) -> Unit = {}
    ) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.toggleHabitCompletion(habit)
            val count = preferencesRepository.incrementCompletedTasks()
            onCompletedCountUpdated(count)
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.deleteHabit(habit)
        }
    }

    fun addWellnessLog(
        moodScore: Int,
        energyScore: Int,
        focusMinutes: Int,
        sleepHours: Float,
        gratitudeReflection: String,
        onCompletedCountUpdated: (Int) -> Unit = {}
    ) {
        viewModelScope.launch(safeExceptionHandler) {
            repository.addWellnessLog(moodScore, energyScore, focusMinutes, sleepHours, gratitudeReflection)
            val count = preferencesRepository.incrementCompletedTasks()
            onCompletedCountUpdated(count)
        }
    }
}

private data class Quintuple<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
