# Zenith 360: AI Life, Habit & Wealth Architect (`com.zenith.architect.pro`)

100% Kotlin + Jetpack Compose Production Android Application engineered for zero-PC, mobile-only compilation and signing via [GitHub Actions](https://docs.github.com/actions).

## Core Identifiers
- **App Name**: Zenith 360
- **Application ID / Namespace**: `com.zenith.architect.pro`
- **GitHub Repository**: `zenith-dev-mobile/zenith-360-android`
- **AdMob App ID**: `ca-app-pub-8550257135927026~3441027809`
- **AdMob Banner Unit ID**: `ca-app-pub-8550257135927026/1880534123`
- **AdMob Interstitial Unit ID**: `ca-app-pub-8550257135927026/6354452409`
- **AdMob Rewarded Unit ID**: `ca-app-pub-8550257135927026/9707053253`
